public class FunctionNode implements Node {
	public FunctionNode(String functionName, Node operand) {
		// TODO
	}
}