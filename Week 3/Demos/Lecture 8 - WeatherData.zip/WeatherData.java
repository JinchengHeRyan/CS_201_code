public class WeatherData {
	public static String getWordBefore(String html, int i) {
		String word = "";
		while (!Character.isSpaceChar(html.charAt(i))) {
			word = html.charAt(i--) + word;
		}
		return word;
	}

	public static void downloadWeatherData(String url) {
		System.err.println("Loading...");

		In page = new In(url);
		String html = page.readAll();
		
		Out o = new Out("downloaded_file.html");
		o.print(html);

		System.err.println("Finished loading");

		int lastIndex = 0;
		String pattern1 = "<a href='/lishi/beijing/";
		while (true) {
			int i1 = html.indexOf(pattern1, lastIndex);
			if (i1 == -1) {
				break;
			}

			int i2 = html.indexOf(".html", i1);
			String date = html.substring(i1 + pattern1.length(), i2);

			int i3 = html.indexOf("℃", i2);
			if (i3 == -1) {
				break;
			}
			String high = getWordBefore(html, i3 - 1);
			if (high.length() == 0) {
				break;
			}
			System.out.println(date + "," + high);
			
			lastIndex = i3;
		}
	}

	public static void main(String[] args) {
		downloadWeatherData(args[0]);
	}
}